//
//  ViewController.swift
//  samplePdf
//
//  Created by Ayush Mehra on 04/05/20.
//  Copyright © 2020 Ayush Mehra. All rights reserved.
//

import UIKit
import SimplePDF
class ViewController: UIViewController {
@IBOutlet weak var webView:UIWebView!
@IBOutlet weak var viewObj: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialiseView()
        // Do any additional setup after loading the view.
    }
    
    func initialiseView()
   {
    let a4PaperSize = CGSize(width: 595, height: 842)
    let pdf = SimplePDF(pageSize: a4PaperSize)

    pdf.setContentAlignment(.right)

    // add logo image
    let logoImage = UIImage(named:"simple_pdf_logo")!
    pdf.addImage(logoImage)

    pdf.setContentAlignment(.center)
    pdf.addLineSpace(30)
    pdf.addText("PAYMENT ACKNOWLEDGEMENT")
    pdf.addLineSpace(10)
    pdf.setContentAlignment(.left)

    pdf.setContentAlignment(.left)
   // pdf.addLineSpace(30)
    let main_string = "Fields specific to the payment gateway *"
    let string_to_color = "Fields specific to the payment gateway *"

    let range = (main_string as NSString).range(of: string_to_color)
    var attributedString = NSMutableAttributedString(string:main_string)
    attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red , range: range)
    let dataArray1 = [[" Account No : Test1313132\n \n Amount: 123\n \n Test1313132 \n \n Transaction Date & Time: 12/4/20\n \n Payment Status: failed\n  \n " + (attributedString .mutableString as String)]]
   let dataArray = [[" Please Note: \n In case, your Adani Electricity account \n has been disconnected for non-payment,\n request you to call 19122 for re-connection support.For \n any support pertaining to this payment,\n please write to \n Helpdesk.Mumbaielectricity@adani.com ", "Test1313132"]]
    
  //  pdf.setBorder()
    

    pdf.addTable(1, columnCount: 1, rowHeight: 250.0, columnWidth: 550.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray1)
   
    pdf.addLineSpace(30)
    pdf.addTable(1, columnCount: 1, rowHeight: 150.0, columnWidth: 550.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray)
    

    pdf.addLineSpace(20.0)
    pdf.setContentAlignment(.left)
//
    pdf.addLineSpace(20.0)
    pdf.addText("*Note:\n - There are 3 payment gateways that need to be configured on the mobile app - Billdesk, Paytm and Ingenico - There a certain fields which are specific to the payment gateways, which need to be included in the payment aknowledgement")

//    let point = CGPoint(x: 0, y: 0)
//    let point1 = CGPoint(x: 20, y: 20)
//    pdf.drawLineFromPoint(point, to: point, lineWidth: 5)
    // Generate PDF data and save to a local file.
    if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
        
        let fileName = "example.pdf"
        let documentsFileName = documentDirectories + "/" + fileName
        
        let pdfData = pdf.generatePDFdata()
       
        do{
            try pdfData.write(to: URL(fileURLWithPath: documentsFileName), options: .atomic)
            
            print("\nThe generated pdf can be found at:")
            print("\n\t\(documentsFileName)\n")
        }catch{
            print(error)
        }
         let pdf =  URL(fileURLWithPath: documentsFileName)  
              let req = NSURLRequest(url: pdf)
              webView.loadRequest(req as URLRequest)
            
    }
   
    }

    func getPointForView(_ view : UIView) -> (x:CGFloat,y:CGFloat)
    {
        let x = view.frame.origin.x
        let y = view.frame.origin.y
        return (x,y)
    }
    

}

